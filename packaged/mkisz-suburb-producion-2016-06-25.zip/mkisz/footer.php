		</div>
		<div class="footer clear row">
        	<p>&copy; <?php the_time(__('Y')) ?> <?php bloginfo('name'); ?>. Minden jog fenntartva.</p>
            <p class="about">Weboldal: <a href="http://www.onlineprojects.hu">OnlineProjects.hu</a> & <a href="http://www.wpshower.com" title="WPSHOWER">WPSHOWER</a></p>
        </div>
	</div><!-- #wrapper -->
<?php wp_footer(); ?>
</body>
</html> 

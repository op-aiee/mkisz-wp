<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="<?php bloginfo('text_direction'); ?>" xml:lang="<?php bloginfo('language'); ?>">
<head>
    <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<title>
        <?php
            global $page, $paged;
            wp_title('|', true, 'right');
            bloginfo('name');
            $site_description = get_bloginfo('description', 'display');
            if ( $site_description && ( is_home() || is_front_page()))
                echo " | $site_description";
            if ($paged >= 2 || $page >= 2)
                echo ' | ' . sprintf( __('Page %s'), max($paged, $page));
        ?>
    </title>
    <meta http-equiv="Content-language" content="<?php bloginfo('language'); ?>" />
    <link rel="profile" href="http://gmpg.org/xfn/11" />
    <link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/images/favico.ico" type="image/x-icon" />
    <link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_url'); ?>" />

    <!-- import mkisz css and fonts -->
	<link href='https://fonts.googleapis.com/css?family=Lora:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('template_url'); ?>/foundation/css/app.css" />
    <link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('template_url'); ?>/foundation/css/foundation.css" />

    <!--[if IE]><link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('template_url'); ?>/ie.css" /><![endif]-->
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
    <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
    <link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>"/>
    <link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
    <?php
        wp_enqueue_script( 'jquery' );
        wp_enqueue_script( 'lazyload', get_template_directory_uri() . '/js/jquery.lazyload.mini.js', 'jquery', false );
        if ( is_singular() ) wp_enqueue_script( 'comment-reply' );
        wp_enqueue_script( 'script', get_template_directory_uri() . '/js/script.js', 'jquery', false );
    ?>
    <?php wp_head(); ?>
</head>
<body>
	<div class="page">
	<div class="row medium-collapse large-collapse">
	<div class="small-3 medium-3 large-3 columns">
		        		
		        		<a href="<?php bloginfo("url"); ?>/"><img src="<?php echo get_option('suburbia_apropos'); ?>"/></a>  
	</div>
	<div class="small-12 medium-9 large-9 columns">
			<nav id="site-navigation" class="main-navigation top-bar" role="navigation">

				<div class="top-bar-right">
					<?php foundationpress_top_bar_r(); ?>

					<?php if ( ! get_theme_mod( 'wpt_mobile_menu_layout' ) || get_theme_mod( 'wpt_mobile_menu_layout' ) == 'topbar' ) : ?>
						<?php get_template_part( 'template-parts/mobile-top-bar' ); ?>
					<?php endif; ?>
				</div>
			</nav>
			<div class="row small-up-1 medium-up-3 large-up-3 medium-collapse large-collapse">
			<div class="column"><img src="https://placeholdit.imgix.net/~text?txtsize=33&txt=aktu%C3%A1lis&w=500&h=400"></div>
			<div class="column"><img src="https://placeholdit.imgix.net/~text?txtsize=33&txt=archív&w=500&h=400"></div>
			<div class="column"><img src="https://placeholdit.imgix.net/~text?txtsize=33&txt=külső esemény&w=500&h=400"></div>
			</div>
	</div>
	</div>
		<div class="row">
		<div class="header clear">
		</div>
		</div>
        <div class="middle clear row">
